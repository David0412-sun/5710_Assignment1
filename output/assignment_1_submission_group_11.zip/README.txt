ROSE5710 Assignment 1: Kinematics

Contains both completed Python files, the coursework report PDF,
and original measured FK/IK JSON.

The Python files run inside Open_Duck_Playground under
assignments/assignment_1_kinematics/.

Use Python 3.11 with the project dependencies installed.
