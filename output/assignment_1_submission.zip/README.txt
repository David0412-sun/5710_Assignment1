ROSE5710 Assignment 1: Kinematics

Contains both completed Python files, the coursework report PDF,
original measured FK/IK JSON and recorded environment, and the
complete LaTeX sources (also supplied as a separate ZIP).

The Python files run inside Open_Duck_Playground under
assignments/assignment_1_kinematics/. The runnable project,
dependencies and tests are available at:
https://github.com/David0412-sun/5710_Assignment1

Follow the repository README for the Python 3.11 environment and
LaTeX rebuild commands. No simulations run during report building.
