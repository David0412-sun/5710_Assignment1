ROSE5710 Assignment 1: Kinematics

Submission: both completed Python files, the PDF containing the three
modified D-H tables and signs, and measured FK/IK comparison results.

The two scripts run within the original Open_Duck_Playground project.
Place them in assignments/assignment_1_kinematics/. The full runnable
project, dependencies, tests and report builder are available at:
https://github.com/David0412-sun/5710_Assignment1

Use Python 3.11 and follow the project README.
